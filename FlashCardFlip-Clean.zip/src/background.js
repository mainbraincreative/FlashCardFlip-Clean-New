import { OPENAI_API_KEY } from './config.js';

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
  chrome.contextMenus.create({
    id: 'createFlashcard',
    title: 'Create Flashcard',
    contexts: ['selection']
  });
});

async function createFlashcardWithGPT(text) {
  try {
    const systemPrompt = `You are an expert at creating highly effective flashcards for optimal learning and retention. Follow these principles:
1. Front side: Extract the most important concept, using 1-5 words. Make it clear and memorable.
2. Back side: Provide a concise yet complete explanation in 1-2 sentences. Focus on understanding, not memorization.
3. Avoid ambiguity: Ensure the front clearly connects to the back.
4. Use active voice and clear language.
5. If the text contains a date, name, or specific fact, make it a clear part of the answer, not the prompt.
6. For cause-effect relationships, put the cause on front, effect on back.
7. For definitions, put the term on front, meaning on back.
8. For processes, put the process name on front, steps on back.`;

    const userPrompt = `Create a flashcard from this text by identifying the core concept and its best explanation. The selected concept should be something worth memorizing and understanding.

Source text: "${text}"

Respond only with a JSON object in this exact format:
{
  "front": "Key concept (1-5 words)",
  "back": "Clear, concise explanation (1-2 sentences)"
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: userPrompt
          }
        ],
        temperature: 0.4  // Reduced for more consistent outputs
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const parsedContent = JSON.parse(data.choices[0].message.content);
    
    return {
      term: parsedContent.front,
      definition: parsedContent.back,
      created: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error creating flashcard:', error);
    return {
      term: text.split(' ').slice(0, 5).join(' '),
      definition: text,
      created: new Date().toISOString()
    };
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'createFlashcard') {
    const selectedText = info.selectionText.trim();
    
    try {
      chrome.action.setBadgeText({ text: '...' });
      
      const cardContent = await createFlashcardWithGPT(selectedText);
      
      chrome.storage.sync.get(['flashcards'], function(result) {
        const flashcards = result.flashcards || [];
        flashcards.unshift(cardContent);
        
        chrome.storage.sync.set({ flashcards: flashcards }, () => {
          chrome.action.setBadgeText({ text: '' });
          chrome.action.openPopup().catch(() => {
            chrome.action.setBadgeText({ text: '✓' });
            setTimeout(() => {
              chrome.action.setBadgeText({ text: '' });
            }, 1000);
          });
        });
      });
    } catch (error) {
      console.error('Error processing flashcard:', error);
      chrome.action.setBadgeText({ text: '!' });
      setTimeout(() => {
        chrome.action.setBadgeText({ text: '' });
      }, 2000);
    }
  }
});